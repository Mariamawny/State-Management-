package com.elgendy.flutter_state_management_bloc_cubit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
